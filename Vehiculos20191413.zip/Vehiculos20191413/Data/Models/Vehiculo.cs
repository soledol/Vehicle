using System.ComponentModel.DataAnnotations;

namespace Vehiculos20191413.Data.Models;

public class Vehiculo
{
    
        public int VehicleId { get; set; } 
            public Models? Model { get; set; }
                public int Year { get; set; }

}

public class Models
{
        public int VehicleId { get; set; } 
            public int IdBrand { get; set; } 
                public virtual Brands? Brand { get; set; }
                    public string Name { get; set; }= null!;
}

public class Brands
{
        public int VehicleId { get; set; } 
            public string Name { get; set; } = null!;
}