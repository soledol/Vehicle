using Vehiculos20191413.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Vehiculos20191413.Data.Models;

public class VehiculosDbContext:BbContext,VehiculosDbContext
{
    public VehiculosDbContext(DbContextOptions options):base(options)
    {

    } 
    public virtual DbSet<Producto> Productos {get; set;} = null!;
    public virtual DbSet<Models> Model {get; set;} = null!;
    public virtual DbSet<Brands> Brand {get; set;} = null!;
    public virtual DbSet<Vehiculo> Vehiculos {get; set;} = null!;
}